#include <iostream>

using namespace std;
extern "C" void Print();

void Print() {
    cout << "__cplusplus: " << __cplusplus << endl;
    cout << "__DATE__: " << __DATE__ << endl;
    cout << "__TIME__: " << __TIME__ << endl;
    cout << "__FILE__: " << __FILE__ << endl;
    cout << "__STDC__: " << __STDC__ << endl;
    cout << "__ARM_ARCH: " << __ARM_ARCH << endl;
    cout << "__ARM_ARCH_ISA_THUMB: " << __ARM_ARCH_ISA_THUMB << endl;
    cout << "__ARM_SIZEOF_MINIMAL_ENUM: " << __ARM_SIZEOF_MINIMAL_ENUM << endl;
    cout << "__ARM_SIZEOF_WCHAR_T: " << __ARM_SIZEOF_WCHAR_T << endl;

    float value;
    float bar = (float) 2.9;

    cout << "Escreva um valor com casas decimais: " << endl;
    cin >> value;
    float soma;

    soma = value + bar;
    cout << "A soma de: " << value << " com o valor: " << bar << " é igual à: " << soma << endl;
}
